/* This file is created by MySQLReback 2016-01-27 17:12:55 */
 DROP TABLE IF EXISTS `admin`;
/* MySQLReback Separation */
 CREATE TABLE `admin` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `account` varchar(64) NOT NULL DEFAULT '',
  `nickname` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0',
  `last_login_ip` varchar(40) NOT NULL DEFAULT '',
  `login_count` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `email` varchar(50) NOT NULL DEFAULT '',
  `remark` varchar(255) NOT NULL DEFAULT '',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `admin_status` tinyint(1) NOT NULL DEFAULT '0',
  `googlepass` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `admin` DROP index `account`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `admin_access`;
/* MySQLReback Separation */
 CREATE TABLE `admin_access` (
  `admin_id` smallint(6) unsigned NOT NULL DEFAULT '0',
  `node_id` smallint(6) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) NOT NULL DEFAULT '0',
  `pid` smallint(6) NOT NULL DEFAULT '0',
  KEY `adminId` (`admin_id`),
  KEY `nodeId` (`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `admin_access` DROP index `adminId`, DROP index `nodeId`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `area`;
/* MySQLReback Separation */
 CREATE TABLE `area` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `地区编码` varchar(255) DEFAULT NULL,
  `上级编码` varchar(255) DEFAULT NULL,
  `地区名称` varchar(255) DEFAULT NULL,
  `地区级别` varchar(255) DEFAULT NULL,
  `是否末级` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `地区编码` (`地区编码`) USING BTREE,
  KEY `id` (`id`) USING BTREE,
  KEY `上级编码` (`上级编码`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `area` DROP index `地区编码`, DROP index `id`, DROP index `上级编码`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `config`;
/* MySQLReback Separation */
 CREATE TABLE `config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `data` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `config` DROP index `name`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_一级店消费购物车`;
/* MySQLReback Separation */
 CREATE TABLE `dms_一级店消费购物车` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `产品id` int(11) NOT NULL DEFAULT '0',
  `数量` int(4) NOT NULL DEFAULT '0',
  `编号` varchar(50) NOT NULL DEFAULT '',
  `操作时间` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_个人业绩_业绩`;
/* MySQLReback Separation */
 CREATE TABLE `dms_个人业绩_业绩` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` int(11) NOT NULL DEFAULT '0',
  `userid` int(8) NOT NULL DEFAULT '0',
  `val` decimal(14,2) NOT NULL DEFAULT '0.00',
  `saleid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_二级店消费购物车`;
/* MySQLReback Separation */
 CREATE TABLE `dms_二级店消费购物车` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `产品id` int(11) NOT NULL DEFAULT '0',
  `数量` int(4) NOT NULL DEFAULT '0',
  `编号` varchar(50) NOT NULL DEFAULT '',
  `操作时间` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_产品`;
/* MySQLReback Separation */
 CREATE TABLE `dms_产品` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `产品编码` varchar(100) NOT NULL DEFAULT '',
  `名称` varchar(100) NOT NULL DEFAULT '',
  `分类` varchar(50) NOT NULL DEFAULT '',
  `规格` varchar(50) NOT NULL DEFAULT '',
  `描述` text NOT NULL,
  `图片` varchar(200) NOT NULL DEFAULT '',
  `成本价` double(12,2) NOT NULL DEFAULT '0.00',
  `价格` double(12,2) NOT NULL DEFAULT '0.00',
  `重量` double(12,2) NOT NULL DEFAULT '0.00',
  `PV` double(12,2) NOT NULL DEFAULT '0.00',
  `所属功能` varchar(100) NOT NULL DEFAULT '',
  `顺序` int(11) NOT NULL DEFAULT '0',
  `数量` int(10) NOT NULL DEFAULT '0',
  `可订购数量` int(10) NOT NULL DEFAULT '0',
  `添加时间` int(11) NOT NULL DEFAULT '0',
  `修改时间` int(11) NOT NULL DEFAULT '0',
  `状态` varchar(10) NOT NULL DEFAULT '使用',
  PRIMARY KEY (`id`),
  KEY `分类` (`分类`),
  KEY `状态` (`状态`),
  KEY `可订购数量` (`可订购数量`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_产品` DROP index `分类`, DROP index `状态`, DROP index `可订购数量`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_产品套餐`;
/* MySQLReback Separation */
 CREATE TABLE `dms_产品套餐` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `产品id` int(100) NOT NULL DEFAULT '0',
  `名称` varchar(100) NOT NULL DEFAULT '',
  `分类` varchar(50) NOT NULL DEFAULT '',
  `规格` varchar(50) NOT NULL DEFAULT '',
  `价格` double(12,2) NOT NULL DEFAULT '0.00',
  `描述` text NOT NULL,
  `图片` varchar(200) NOT NULL DEFAULT '',
  `数量` int(10) NOT NULL DEFAULT '0',
  `添加时间` int(11) NOT NULL DEFAULT '0',
  `修改时间` int(11) NOT NULL DEFAULT '0',
  `状态` varchar(10) NOT NULL DEFAULT '使用',
  PRIMARY KEY (`id`),
  KEY `分类` (`分类`),
  KEY `状态` (`状态`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_产品套餐` DROP index `分类`, DROP index `状态`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_产品库存`;
/* MySQLReback Separation */
 CREATE TABLE `dms_产品库存` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `产品id` int(11) NOT NULL DEFAULT '0',
  `报单id` int(11) NOT NULL DEFAULT '0',
  `产品节点` varchar(50) NOT NULL DEFAULT '',
  `数量` int(11) NOT NULL DEFAULT '0',
  `备注` varchar(255) NOT NULL DEFAULT '',
  `操作时间` int(11) NOT NULL DEFAULT '0',
  `操作人` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `报单id` (`报单id`),
  KEY `产品id` (`产品id`),
  KEY `产品节点` (`产品节点`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_产品库存` DROP index `报单id`, DROP index `产品id`, DROP index `产品节点`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_产品物流管理`;
/* MySQLReback Separation */
 CREATE TABLE `dms_产品物流管理` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `发往省份` varchar(50) NOT NULL DEFAULT '',
  `国家` varchar(50) NOT NULL DEFAULT '',
  `首重` double(12,2) NOT NULL DEFAULT '0.00',
  `首重价格` double(12,2) NOT NULL DEFAULT '0.00',
  `续重价格` double(12,2) NOT NULL DEFAULT '0.00',
  `是否全国标准` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_产品订单`;
/* MySQLReback Separation */
 CREATE TABLE `dms_产品订单` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `报单id` int(11) NOT NULL DEFAULT '0',
  `产品id` int(11) NOT NULL DEFAULT '0',
  `产品节点` varchar(50) NOT NULL DEFAULT '',
  `名称` varchar(100) NOT NULL DEFAULT '',
  `分类` varchar(50) NOT NULL DEFAULT '',
  `规格` varchar(50) NOT NULL DEFAULT '',
  `数量` int(11) NOT NULL DEFAULT '0',
  `价格` double(12,2) NOT NULL DEFAULT '0.00',
  `PV` double(12,2) NOT NULL DEFAULT '0.00',
  `总重量` double(12,2) NOT NULL DEFAULT '0.00',
  `总价` double(12,2) NOT NULL DEFAULT '0.00',
  `总PV` double(12,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `报单id` (`报单id`),
  KEY `产品id` (`产品id`),
  KEY `产品节点` (`产品节点`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_产品订单` DROP index `报单id`, DROP index `产品id`, DROP index `产品节点`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_产品_分类`;
/* MySQLReback Separation */
 CREATE TABLE `dms_产品_分类` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `名称` varchar(100) NOT NULL DEFAULT '',
  `排序` int(4) NOT NULL DEFAULT '0',
  `创建时间` int(10) NOT NULL DEFAULT '0',
  `状态` varchar(10) NOT NULL DEFAULT '使用',
  PRIMARY KEY (`id`),
  KEY `状态` (`状态`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_产品_分类` DROP index `状态`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_产品_功能`;
/* MySQLReback Separation */
 CREATE TABLE `dms_产品_功能` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `名称` varchar(100) NOT NULL DEFAULT '',
  `创建时间` int(10) NOT NULL DEFAULT '0',
  `节点名称` varchar(100) NOT NULL DEFAULT '',
  `状态` varchar(10) NOT NULL DEFAULT '使用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_会员`;
/* MySQLReback Separation */
 CREATE TABLE `dms_会员` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `编号` varchar(50) NOT NULL DEFAULT '',
  `pass1` varchar(50) NOT NULL DEFAULT '',
  `pass2` varchar(50) NOT NULL DEFAULT '',
  `pass3` varchar(50) NOT NULL DEFAULT '',
  `姓名` varchar(50) NOT NULL DEFAULT '',
  `收货人` varchar(50) NOT NULL DEFAULT '',
  `昵称` varchar(50) NOT NULL DEFAULT '',
  `注册类型` varchar(50) NOT NULL DEFAULT '',
  `空点` tinyint(1) NOT NULL DEFAULT '0',
  `奖金锁` tinyint(1) NOT NULL DEFAULT '0',
  `注册日期` int(11) NOT NULL DEFAULT '0',
  `审核日期` int(11) NOT NULL DEFAULT '0',
  `登入日期` int(11) NOT NULL DEFAULT '0',
  `状态` varchar(50) NOT NULL DEFAULT '',
  `登陆锁定` tinyint(1) NOT NULL DEFAULT '0',
  `开户银行` varchar(50) NOT NULL DEFAULT '',
  `银行卡号` varchar(50) NOT NULL DEFAULT '',
  `开户名` varchar(50) NOT NULL DEFAULT '',
  `开户地址` varchar(50) NOT NULL DEFAULT '',
  `国家代码` varchar(50) NOT NULL DEFAULT '+086',
  `移动电话` varchar(50) NOT NULL DEFAULT '',
  `固定电话` varchar(50) NOT NULL DEFAULT '',
  `证件号码` varchar(50) NOT NULL DEFAULT '',
  `性别` varchar(50) NOT NULL DEFAULT '',
  `生日` varchar(15) NOT NULL DEFAULT '',
  `email` varchar(200) NOT NULL DEFAULT '',
  `微信账号` varchar(200) NOT NULL DEFAULT '',
  `QQ` varchar(50) NOT NULL DEFAULT '',
  `国家` varchar(50) NOT NULL DEFAULT '',
  `省份` varchar(50) NOT NULL DEFAULT '',
  `城市` varchar(50) NOT NULL DEFAULT '',
  `地区` varchar(50) NOT NULL DEFAULT '',
  `街道` varchar(50) NOT NULL DEFAULT '',
  `代理国家` varchar(50) NOT NULL DEFAULT '',
  `代理省份` varchar(50) NOT NULL DEFAULT '',
  `代理城市` varchar(50) NOT NULL DEFAULT '',
  `代理地区` varchar(50) NOT NULL DEFAULT '',
  `代理街道` varchar(50) NOT NULL DEFAULT '',
  `邮编` varchar(50) NOT NULL DEFAULT '',
  `地址` varchar(255) NOT NULL DEFAULT '',
  `关联账号` varchar(50) NOT NULL DEFAULT '0',
  `月收入` decimal(14,2) NOT NULL DEFAULT '0.00',
  `累计收入` decimal(14,2) NOT NULL DEFAULT '0.00',
  `已发放奖金` decimal(14,2) NOT NULL DEFAULT '0.00',
  `最后登入IP` varchar(50) NOT NULL DEFAULT '',
  `注册级别金额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `是否回本` tinyint(1) NOT NULL DEFAULT '0',
  `服务中心` decimal(1,0) NOT NULL DEFAULT '0',
  `服务中心编号` varchar(50) NOT NULL DEFAULT '',
  `注册人编号` varchar(50) NOT NULL DEFAULT '',
  `sessionid` varchar(50) NOT NULL DEFAULT '',
  `最后访问时间` int(11) NOT NULL DEFAULT '0',
  `密保问题` varchar(220) NOT NULL DEFAULT '',
  `密保答案` varchar(220) NOT NULL DEFAULT '',
  `备注` varchar(1000) NOT NULL DEFAULT '',
  `申请会员级别` decimal(3,0) NOT NULL DEFAULT '1',
  `会员级别` decimal(3,0) NOT NULL DEFAULT '1',
  `赠送会员级别` decimal(3,0) NOT NULL DEFAULT '0',
  `会员级别金额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `会员级别PV` decimal(14,2) NOT NULL DEFAULT '0.00',
  `会员级别单数` int(11) NOT NULL DEFAULT '0',
  `申请管理级别` decimal(3,0) NOT NULL DEFAULT '1',
  `管理级别` decimal(3,0) NOT NULL DEFAULT '1',
  `赠送管理级别` decimal(3,0) NOT NULL DEFAULT '0',
  `管理级别金额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `管理级别PV` decimal(14,2) NOT NULL DEFAULT '0.00',
  `管理级别单数` int(11) NOT NULL DEFAULT '0',
  `申请代理级别` decimal(3,0) NOT NULL DEFAULT '1',
  `代理级别` decimal(3,0) NOT NULL DEFAULT '1',
  `赠送代理级别` decimal(3,0) NOT NULL DEFAULT '0',
  `代理级别金额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `代理级别PV` decimal(14,2) NOT NULL DEFAULT '0.00',
  `代理级别单数` int(11) NOT NULL DEFAULT '0',
  `推荐_上级编号` varchar(50) NOT NULL DEFAULT '',
  `推荐_推荐人数` int(11) NOT NULL DEFAULT '0',
  `推荐_被推荐数` int(11) NOT NULL DEFAULT '0',
  `推荐_团队人数` int(11) NOT NULL DEFAULT '0',
  `推荐_团队总人数` int(11) NOT NULL DEFAULT '0',
  `推荐_层数` int(11) NOT NULL DEFAULT '0',
  `推荐_深度` int(11) NOT NULL DEFAULT '0',
  `推荐_网体数据` longtext NOT NULL,
  `推荐网络显示` varchar(255) NOT NULL DEFAULT '自动',
  `管理_上级编号` varchar(50) NOT NULL DEFAULT '',
  `管理_位置` varchar(10) NOT NULL DEFAULT '',
  `管理_团队人数` int(11) NOT NULL DEFAULT '0',
  `管理_团队总人数` int(11) NOT NULL DEFAULT '0',
  `管理_层数` int(11) NOT NULL DEFAULT '0',
  `管理_网体数据` longtext NOT NULL,
  `管理网络显示` varchar(255) NOT NULL DEFAULT '自动',
  `管理_左区` varchar(50) NOT NULL DEFAULT '',
  `管理_左区层深` int(11) NOT NULL DEFAULT '0',
  `管理_左区本期业绩` decimal(14,2) NOT NULL DEFAULT '0.00',
  `管理_左区本日业绩` decimal(14,2) NOT NULL DEFAULT '0.00',
  `管理_左区累计业绩` decimal(14,2) NOT NULL DEFAULT '0.00',
  `管理_左区结转业绩` decimal(14,2) NOT NULL DEFAULT '0.00',
  `管理_右区` varchar(50) NOT NULL DEFAULT '',
  `管理_右区层深` int(11) NOT NULL DEFAULT '0',
  `管理_右区本期业绩` decimal(14,2) NOT NULL DEFAULT '0.00',
  `管理_右区本日业绩` decimal(14,2) NOT NULL DEFAULT '0.00',
  `管理_右区累计业绩` decimal(14,2) NOT NULL DEFAULT '0.00',
  `管理_右区结转业绩` decimal(14,2) NOT NULL DEFAULT '0.00',
  `推荐奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `推荐奖本日` decimal(14,2) NOT NULL DEFAULT '0.00',
  `推荐奖本周` decimal(14,2) NOT NULL DEFAULT '0.00',
  `推荐奖本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `推荐奖累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `推荐奖比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `碰对奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `碰对奖本日` decimal(14,2) NOT NULL DEFAULT '0.00',
  `碰对奖本周` decimal(14,2) NOT NULL DEFAULT '0.00',
  `碰对奖本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `碰对奖累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `碰对奖比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `层碰奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `层碰奖本日` decimal(14,2) NOT NULL DEFAULT '0.00',
  `层碰奖本周` decimal(14,2) NOT NULL DEFAULT '0.00',
  `层碰奖本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `层碰奖累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `层碰奖比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `责任消费` decimal(14,2) NOT NULL DEFAULT '0.00',
  `责任消费本日` decimal(14,2) NOT NULL DEFAULT '0.00',
  `责任消费本周` decimal(14,2) NOT NULL DEFAULT '0.00',
  `责任消费本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `责任消费累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `责任消费比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `责任消费结转` decimal(14,2) NOT NULL DEFAULT '0.00',
  `责任消费单数` decimal(13,2) NOT NULL DEFAULT '0.00',
  `责任消费本日单数` decimal(13,2) NOT NULL DEFAULT '0.00',
  `责任消费本月单数` decimal(13,2) NOT NULL DEFAULT '0.00',
  `责任消费累计单数` decimal(13,2) NOT NULL DEFAULT '0.00',
  `返利奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `返利奖本日` decimal(14,2) NOT NULL DEFAULT '0.00',
  `返利奖本周` decimal(14,2) NOT NULL DEFAULT '0.00',
  `返利奖本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `返利奖累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `返利奖比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `级差奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `级差奖本日` decimal(14,2) NOT NULL DEFAULT '0.00',
  `级差奖本周` decimal(14,2) NOT NULL DEFAULT '0.00',
  `级差奖本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `级差奖累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `级差奖比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `代理级差奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `代理级差奖本日` decimal(14,2) NOT NULL DEFAULT '0.00',
  `代理级差奖本周` decimal(14,2) NOT NULL DEFAULT '0.00',
  `代理级差奖本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `代理级差奖累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `代理级差奖比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `分红奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `分红奖本日` decimal(14,2) NOT NULL DEFAULT '0.00',
  `分红奖本周` decimal(14,2) NOT NULL DEFAULT '0.00',
  `分红奖本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `分红奖累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `分红奖比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `帮扶奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `帮扶奖本日` decimal(14,2) NOT NULL DEFAULT '0.00',
  `帮扶奖本周` decimal(14,2) NOT NULL DEFAULT '0.00',
  `帮扶奖本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `帮扶奖累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `帮扶奖比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `店补` decimal(14,2) NOT NULL DEFAULT '0.00',
  `店补本日` decimal(14,2) NOT NULL DEFAULT '0.00',
  `店补本周` decimal(14,2) NOT NULL DEFAULT '0.00',
  `店补本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `店补累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `店补比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `所得税` decimal(14,2) NOT NULL DEFAULT '0.00',
  `所得税本日` decimal(14,2) NOT NULL DEFAULT '0.00',
  `所得税本周` decimal(14,2) NOT NULL DEFAULT '0.00',
  `所得税本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `所得税累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `所得税比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `个人业绩本日` decimal(14,2) NOT NULL DEFAULT '0.00',
  `个人业绩本周` decimal(14,2) NOT NULL DEFAULT '0.00',
  `个人业绩本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `个人业绩本年` decimal(14,2) NOT NULL DEFAULT '0.00',
  `个人业绩累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `两层人数` decimal(10,2) NOT NULL DEFAULT '0.00',
  `上月业绩` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `编号` (`编号`),
  KEY `id` (`id`),
  KEY `空点` (`空点`),
  KEY `审核日期` (`审核日期`),
  KEY `状态` (`状态`),
  KEY `申请会员级别` (`申请会员级别`),
  KEY `会员级别` (`会员级别`),
  KEY `申请管理级别` (`申请管理级别`),
  KEY `管理级别` (`管理级别`),
  KEY `申请代理级别` (`申请代理级别`),
  KEY `代理级别` (`代理级别`),
  KEY `推荐_层数` (`推荐_层数`),
  KEY `推荐_上级编号` (`推荐_上级编号`),
  KEY `推荐_网体数据` (`推荐_网体数据`(200)),
  KEY `管理_层数` (`管理_层数`),
  KEY `管理_上级编号` (`管理_上级编号`),
  KEY `管理_网体数据` (`管理_网体数据`(200)),
  KEY `两层人数` (`两层人数`),
  KEY `上月业绩` (`上月业绩`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_会员` DROP index `编号`, DROP index `id`, DROP index `空点`, DROP index `审核日期`, DROP index `状态`, DROP index `申请会员级别`, DROP index `会员级别`, DROP index `申请管理级别`, DROP index `管理级别`, DROP index `申请代理级别`, DROP index `代理级别`, DROP index `推荐_层数`, DROP index `推荐_上级编号`, DROP index `推荐_网体数据`, DROP index `管理_层数`, DROP index `管理_上级编号`, DROP index `管理_网体数据`, DROP index `两层人数`, DROP index `上月业绩`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_修改日志`;
/* MySQLReback Separation */
 CREATE TABLE `dms_修改日志` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL DEFAULT '0',
  `logid` int(11) NOT NULL DEFAULT '0',
  `修改人` int(11) NOT NULL DEFAULT '0',
  `修改时间` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `编号` varchar(50) NOT NULL DEFAULT '',
  `pass1` varchar(50) NOT NULL DEFAULT '',
  `pass2` varchar(50) NOT NULL DEFAULT '',
  `pass3` varchar(50) NOT NULL DEFAULT '',
  `姓名` varchar(50) NOT NULL DEFAULT '',
  `收货人` varchar(50) NOT NULL DEFAULT '',
  `别名` varchar(50) NOT NULL DEFAULT '',
  `注册日期` varchar(50) NOT NULL DEFAULT '',
  `空点` tinyint(2) NOT NULL DEFAULT '0',
  `审核日期` varchar(50) NOT NULL DEFAULT '',
  `登入日期` varchar(50) NOT NULL DEFAULT '',
  `状态` varchar(50) NOT NULL DEFAULT '',
  `锁定` varchar(50) NOT NULL DEFAULT '',
  `开户银行` varchar(50) NOT NULL DEFAULT '',
  `银行卡号` varchar(50) NOT NULL DEFAULT '',
  `开户名` varchar(50) NOT NULL DEFAULT '',
  `开户地址` varchar(50) NOT NULL DEFAULT '',
  `移动电话` varchar(50) NOT NULL DEFAULT '',
  `固定电话` varchar(50) NOT NULL DEFAULT '',
  `证件号码` varchar(50) NOT NULL DEFAULT '',
  `性别` varchar(50) NOT NULL DEFAULT '',
  `生日` varchar(15) NOT NULL DEFAULT '',
  `email` varchar(200) NOT NULL DEFAULT '',
  `QQ` varchar(50) NOT NULL DEFAULT '',
  `国家` varchar(50) NOT NULL DEFAULT '',
  `省份` varchar(50) NOT NULL DEFAULT '',
  `城市` varchar(50) NOT NULL DEFAULT '',
  `地区` varchar(50) NOT NULL DEFAULT '',
  `邮编` varchar(50) NOT NULL DEFAULT '',
  `地址` varchar(300) NOT NULL DEFAULT '',
  `服务中心` decimal(1,0) NOT NULL DEFAULT '0',
  `申请会员级别` decimal(3,0) NOT NULL DEFAULT '1',
  `会员级别` decimal(3,0) NOT NULL DEFAULT '1',
  `赠送会员级别` decimal(3,0) NOT NULL DEFAULT '0',
  `会员级别金额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `会员级别PV` decimal(14,2) NOT NULL DEFAULT '0.00',
  `会员级别单数` int(11) NOT NULL DEFAULT '0',
  `会员级别_temp` decimal(14,2) NOT NULL DEFAULT '0.00',
  `申请管理级别` decimal(3,0) NOT NULL DEFAULT '1',
  `管理级别` decimal(3,0) NOT NULL DEFAULT '1',
  `赠送管理级别` decimal(3,0) NOT NULL DEFAULT '0',
  `管理级别金额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `管理级别PV` decimal(14,2) NOT NULL DEFAULT '0.00',
  `管理级别单数` int(11) NOT NULL DEFAULT '0',
  `管理级别_temp` decimal(14,2) NOT NULL DEFAULT '0.00',
  `申请代理级别` decimal(3,0) NOT NULL DEFAULT '1',
  `代理级别` decimal(3,0) NOT NULL DEFAULT '1',
  `赠送代理级别` decimal(3,0) NOT NULL DEFAULT '0',
  `代理级别金额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `代理级别PV` decimal(14,2) NOT NULL DEFAULT '0.00',
  `代理级别单数` int(11) NOT NULL DEFAULT '0',
  `代理级别_temp` decimal(14,2) NOT NULL DEFAULT '0.00',
  `推荐网络显示` varchar(255) NOT NULL DEFAULT '自动',
  `管理网络显示` varchar(255) NOT NULL DEFAULT '自动',
  `电子货币锁定` tinyint(1) NOT NULL DEFAULT '0',
  `消费货币锁定` tinyint(1) NOT NULL DEFAULT '0',
  `游戏钱包锁定` tinyint(1) NOT NULL DEFAULT '0',
  `推荐奖比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `碰对奖比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `层碰奖比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `责任消费比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `返利奖比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `级差奖比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `代理级差奖比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `分红奖比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `帮扶奖比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `店补比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `所得税比例` decimal(5,2) NOT NULL DEFAULT '100.00',
  `两层人数` decimal(10,2) NOT NULL DEFAULT '0.00',
  `上月业绩` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_公告`;
/* MySQLReback Separation */
 CREATE TABLE `dms_公告` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `netname` varchar(255) NOT NULL DEFAULT '',
  `查看权限` int(11) NOT NULL DEFAULT '0',
  `标题` varchar(50) NOT NULL DEFAULT '',
  `标题特效` text NOT NULL,
  `内容` text NOT NULL,
  `发布人` varchar(50) NOT NULL DEFAULT '',
  `type` varchar(100) NOT NULL DEFAULT '',
  `语言` varchar(50) NOT NULL DEFAULT '',
  `创建时间` int(11) NOT NULL DEFAULT '0',
  `顺序` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_号码`;
/* MySQLReback Separation */
 CREATE TABLE `dms_号码` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `编组` int(11) NOT NULL DEFAULT '0',
  `号码` varchar(50) NOT NULL DEFAULT '',
  `姓名` varchar(50) NOT NULL DEFAULT '',
  `编号` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_号码编组`;
/* MySQLReback Separation */
 CREATE TABLE `dms_号码编组` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `分组名称` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_商城产品`;
/* MySQLReback Separation */
 CREATE TABLE `dms_商城产品` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `产品编码` varchar(100) NOT NULL DEFAULT '',
  `名称` varchar(100) NOT NULL DEFAULT '',
  `分类` varchar(50) NOT NULL DEFAULT '',
  `规格` varchar(50) NOT NULL DEFAULT '',
  `描述` text NOT NULL,
  `图片` varchar(200) NOT NULL DEFAULT '',
  `成本价` double(12,2) NOT NULL DEFAULT '0.00',
  `价格` double(12,2) NOT NULL DEFAULT '0.00',
  `重量` double(12,2) NOT NULL DEFAULT '0.00',
  `PV` double(12,2) NOT NULL DEFAULT '0.00',
  `所属功能` varchar(100) NOT NULL DEFAULT '',
  `顺序` int(11) NOT NULL DEFAULT '0',
  `数量` int(10) NOT NULL DEFAULT '0',
  `可订购数量` int(10) NOT NULL DEFAULT '0',
  `添加时间` int(11) NOT NULL DEFAULT '0',
  `修改时间` int(11) NOT NULL DEFAULT '0',
  `状态` varchar(10) NOT NULL DEFAULT '使用',
  PRIMARY KEY (`id`),
  KEY `分类` (`分类`),
  KEY `状态` (`状态`),
  KEY `可订购数量` (`可订购数量`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_商城产品` DROP index `分类`, DROP index `状态`, DROP index `可订购数量`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_商城产品套餐`;
/* MySQLReback Separation */
 CREATE TABLE `dms_商城产品套餐` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `产品id` int(100) NOT NULL DEFAULT '0',
  `名称` varchar(100) NOT NULL DEFAULT '',
  `分类` varchar(50) NOT NULL DEFAULT '',
  `规格` varchar(50) NOT NULL DEFAULT '',
  `价格` double(12,2) NOT NULL DEFAULT '0.00',
  `描述` text NOT NULL,
  `图片` varchar(200) NOT NULL DEFAULT '',
  `数量` int(10) NOT NULL DEFAULT '0',
  `添加时间` int(11) NOT NULL DEFAULT '0',
  `修改时间` int(11) NOT NULL DEFAULT '0',
  `状态` varchar(10) NOT NULL DEFAULT '使用',
  PRIMARY KEY (`id`),
  KEY `分类` (`分类`),
  KEY `状态` (`状态`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_商城产品套餐` DROP index `分类`, DROP index `状态`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_商城产品_分类`;
/* MySQLReback Separation */
 CREATE TABLE `dms_商城产品_分类` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `名称` varchar(100) NOT NULL DEFAULT '',
  `排序` int(4) NOT NULL DEFAULT '0',
  `创建时间` int(10) NOT NULL DEFAULT '0',
  `状态` varchar(10) NOT NULL DEFAULT '使用',
  PRIMARY KEY (`id`),
  KEY `状态` (`状态`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_商城产品_分类` DROP index `状态`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_密保`;
/* MySQLReback Separation */
 CREATE TABLE `dms_密保` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `密保问题` varchar(100) DEFAULT '',
  `添加时间` int(11) DEFAULT '0',
  `管理员` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_层碰奖`;
/* MySQLReback Separation */
 CREATE TABLE `dms_层碰奖` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `编号` varchar(50) NOT NULL DEFAULT '',
  `时间` int(11) NOT NULL DEFAULT '0',
  `层数` int(11) NOT NULL DEFAULT '0',
  `金额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `数据` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_快递`;
/* MySQLReback Separation */
 CREATE TABLE `dms_快递` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company` varchar(255) DEFAULT '' COMMENT '公司名称',
  `address` varchar(255) DEFAULT '' COMMENT '公司地址',
  `tel` varchar(255) DEFAULT '' COMMENT '联系电话',
  `contact` varchar(255) DEFAULT '' COMMENT '联系人',
  `url` varchar(255) DEFAULT '' COMMENT '公司网址',
  `addtime` int(11) DEFAULT '0' COMMENT '添加时间',
  `state` varchar(10) DEFAULT '是',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_报单`;
/* MySQLReback Separation */
 CREATE TABLE `dms_报单` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL DEFAULT '0',
  `报单编号` varchar(50) NOT NULL DEFAULT '',
  `编号` varchar(50) NOT NULL DEFAULT '',
  `购买日期` int(11) NOT NULL DEFAULT '0',
  `到款日期` int(11) NOT NULL DEFAULT '0',
  `发货日期` int(11) NOT NULL DEFAULT '0',
  `收货日期` int(11) NOT NULL DEFAULT '0',
  `服务中心编号` varchar(50) NOT NULL DEFAULT '',
  `注册人编号` varchar(50) NOT NULL DEFAULT '',
  `付款人编号` varchar(50) NOT NULL DEFAULT '',
  `报单类别` varchar(50) NOT NULL DEFAULT '',
  `报单状态` varchar(50) NOT NULL DEFAULT '',
  `物流状态` varchar(50) NOT NULL DEFAULT '未发货',
  `订单备注` varchar(255) NOT NULL DEFAULT '',
  `快递公司` varchar(50) NOT NULL DEFAULT '',
  `快递订单` varchar(100) NOT NULL DEFAULT '',
  `快递备注` varchar(255) NOT NULL DEFAULT '',
  `收货国家` varchar(50) NOT NULL DEFAULT '',
  `收货省份` varchar(50) NOT NULL DEFAULT '',
  `收货城市` varchar(50) NOT NULL DEFAULT '',
  `收货地区` varchar(50) NOT NULL DEFAULT '',
  `收货街道` varchar(50) NOT NULL DEFAULT '',
  `收货地址` varchar(150) NOT NULL DEFAULT '',
  `收货人` varchar(50) NOT NULL DEFAULT '',
  `联系电话` varchar(50) NOT NULL DEFAULT '',
  `发货类型` varchar(50) NOT NULL DEFAULT '',
  `发货人` varchar(50) NOT NULL DEFAULT '',
  `发货方式` varchar(50) NOT NULL DEFAULT '',
  `代理国家` varchar(50) NOT NULL DEFAULT '',
  `代理省份` varchar(50) NOT NULL DEFAULT '',
  `代理城市` varchar(50) NOT NULL DEFAULT '',
  `代理地区` varchar(50) NOT NULL DEFAULT '',
  `代理街道` varchar(50) NOT NULL DEFAULT '',
  `报单金额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `报单单数` int(11) NOT NULL DEFAULT '0',
  `购物金额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `购物PV` decimal(14,2) NOT NULL DEFAULT '0.00',
  `折扣` decimal(14,2) NOT NULL DEFAULT '1.00',
  `accbank` longtext NOT NULL,
  `accokstr` longtext NOT NULL,
  `实付款` decimal(14,2) NOT NULL DEFAULT '0.00',
  `优先级` decimal(14,2) NOT NULL DEFAULT '0.00',
  `升级数据` decimal(10,0) NOT NULL DEFAULT '0',
  `回填` tinyint(1) NOT NULL DEFAULT '0',
  `回填金额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `已回金额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `回填日期` int(11) NOT NULL DEFAULT '0',
  `byname` varchar(255) NOT NULL DEFAULT '',
  `paydata` varchar(500) NOT NULL DEFAULT '',
  `产品` tinyint(1) NOT NULL DEFAULT '0',
  `是否推广链接` varchar(20) NOT NULL DEFAULT '0',
  `old_lv` int(11) NOT NULL DEFAULT '0',
  `产品总重量` decimal(13,2) NOT NULL DEFAULT '0.00',
  `物流费` decimal(14,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `编号` (`编号`),
  KEY `到款日期` (`到款日期`),
  KEY `报单状态` (`报单状态`),
  KEY `报单类别` (`报单类别`),
  KEY `byname` (`byname`),
  KEY `报单金额` (`报单金额`),
  KEY `回填` (`回填`),
  CONSTRAINT `fk_user_id` FOREIGN KEY (`userid`) REFERENCES `dms_会员` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_报单` DROP index `userid`, DROP index `编号`, DROP index `到款日期`, DROP index `报单状态`, DROP index `报单类别`, DROP index `byname`, DROP index `报单金额`, DROP index `回填`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_报单回填明细`;
/* MySQLReback Separation */
 CREATE TABLE `dms_报单回填明细` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `编号` varchar(50) NOT NULL DEFAULT '',
  `saleid` int(11) NOT NULL DEFAULT '0',
  `结算日期` int(11) NOT NULL DEFAULT '0',
  `回填日期` int(11) NOT NULL DEFAULT '0',
  `转正方式` varchar(50) NOT NULL DEFAULT '',
  `金额` decimal(13,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `saleid` (`saleid`),
  KEY `编号` (`编号`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_报单回填明细` DROP index `saleid`, DROP index `编号`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_提现`;
/* MySQLReback Separation */
 CREATE TABLE `dms_提现` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `类型` varchar(50) NOT NULL DEFAULT '',
  `编号` varchar(50) NOT NULL DEFAULT '',
  `提现额` decimal(10,2) NOT NULL DEFAULT '0.00',
  `实发` decimal(12,2) NOT NULL DEFAULT '0.00',
  `换算后实发` decimal(12,2) NOT NULL DEFAULT '0.00',
  `手续费` decimal(10,2) NOT NULL DEFAULT '0.00',
  `操作时间` int(11) NOT NULL DEFAULT '0',
  `审核时间` int(11) NOT NULL DEFAULT '0',
  `开户行` varchar(100) NOT NULL DEFAULT '',
  `银行卡号` varchar(100) NOT NULL DEFAULT '',
  `开户地址` varchar(200) NOT NULL DEFAULT '',
  `开户名` varchar(100) NOT NULL DEFAULT '',
  `状态` varchar(10) NOT NULL DEFAULT '',
  `联系电话` varchar(100) NOT NULL DEFAULT '',
  `撤销申请` int(2) NOT NULL DEFAULT '0',
  `撤销理由` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_汇款方式`;
/* MySQLReback Separation */
 CREATE TABLE `dms_汇款方式` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `方式名称` varchar(255) NOT NULL DEFAULT '',
  `添加时间` varchar(50) NOT NULL DEFAULT '',
  `修改时间` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_汇款通知`;
/* MySQLReback Separation */
 CREATE TABLE `dms_汇款通知` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `汇入账户卡号` varchar(255) NOT NULL DEFAULT '',
  `汇入账户` varchar(255) NOT NULL DEFAULT '',
  `汇入账户开户名` varchar(255) NOT NULL DEFAULT '',
  `汇入账户开户行` varchar(255) NOT NULL DEFAULT '',
  `编号` varchar(50) NOT NULL DEFAULT '',
  `开户银行` varchar(50) NOT NULL DEFAULT '',
  `银行卡号` varchar(50) NOT NULL DEFAULT '',
  `开户名` varchar(50) NOT NULL DEFAULT '',
  `汇款时间` varchar(15) NOT NULL DEFAULT '',
  `汇款方式` varchar(15) NOT NULL DEFAULT '',
  `状态` tinyint(1) NOT NULL DEFAULT '0',
  `金额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `换算后金额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `备注` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `编号` (`编号`),
  KEY `状态` (`状态`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_汇款通知` DROP index `编号`, DROP index `状态`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_消费货币明细`;
/* MySQLReback Separation */
 CREATE TABLE `dms_消费货币明细` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `时间` int(11) NOT NULL DEFAULT '0',
  `编号` varchar(50) NOT NULL DEFAULT '',
  `来源` varchar(50) NOT NULL DEFAULT '',
  `类型` varchar(50) NOT NULL DEFAULT '',
  `金额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `余额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `备注` text NOT NULL,
  `删除` int(1) NOT NULL DEFAULT '0',
  `tlename` varchar(50) NOT NULL DEFAULT '',
  `prizename` varchar(50) NOT NULL DEFAULT '',
  `dataid` int(11) NOT NULL DEFAULT '0',
  `adminuser` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `编号` (`编号`),
  KEY `类型` (`类型`),
  KEY `tlename` (`tlename`,`prizename`,`dataid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_消费货币明细` DROP index `编号`, DROP index `类型`, DROP index `tlename`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_游戏钱包明细`;
/* MySQLReback Separation */
 CREATE TABLE `dms_游戏钱包明细` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `时间` int(11) NOT NULL DEFAULT '0',
  `编号` varchar(50) NOT NULL DEFAULT '',
  `来源` varchar(50) NOT NULL DEFAULT '',
  `类型` varchar(50) NOT NULL DEFAULT '',
  `金额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `余额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `备注` text NOT NULL,
  `删除` int(1) NOT NULL DEFAULT '0',
  `tlename` varchar(50) NOT NULL DEFAULT '',
  `prizename` varchar(50) NOT NULL DEFAULT '',
  `dataid` int(11) NOT NULL DEFAULT '0',
  `adminuser` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `编号` (`编号`),
  KEY `类型` (`类型`),
  KEY `tlename` (`tlename`,`prizename`,`dataid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_游戏钱包明细` DROP index `编号`, DROP index `类型`, DROP index `tlename`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_申请回填`;
/* MySQLReback Separation */
 CREATE TABLE `dms_申请回填` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `编号` varchar(50) NOT NULL DEFAULT '',
  `saleid` int(11) NOT NULL DEFAULT '0',
  `申请日期` int(11) NOT NULL DEFAULT '0',
  `审核日期` int(11) NOT NULL DEFAULT '0',
  `转正方式` varchar(50) NOT NULL DEFAULT '',
  `申请状态` varchar(50) NOT NULL DEFAULT '未审核',
  PRIMARY KEY (`id`),
  KEY `saleid` (`saleid`),
  KEY `编号` (`编号`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_申请回填` DROP index `saleid`, DROP index `编号`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_电子货币明细`;
/* MySQLReback Separation */
 CREATE TABLE `dms_电子货币明细` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `时间` int(11) NOT NULL DEFAULT '0',
  `编号` varchar(50) NOT NULL DEFAULT '',
  `来源` varchar(50) NOT NULL DEFAULT '',
  `类型` varchar(50) NOT NULL DEFAULT '',
  `金额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `余额` decimal(14,2) NOT NULL DEFAULT '0.00',
  `备注` text NOT NULL,
  `删除` int(1) NOT NULL DEFAULT '0',
  `tlename` varchar(50) NOT NULL DEFAULT '',
  `prizename` varchar(50) NOT NULL DEFAULT '',
  `dataid` int(11) NOT NULL DEFAULT '0',
  `adminuser` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `编号` (`编号`),
  KEY `类型` (`类型`),
  KEY `tlename` (`tlename`,`prizename`,`dataid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_电子货币明细` DROP index `编号`, DROP index `类型`, DROP index `tlename`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_短信`;
/* MySQLReback Separation */
 CREATE TABLE `dms_短信` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `内容` varchar(255) NOT NULL DEFAULT '',
  `发送时间` int(11) NOT NULL DEFAULT '0',
  `待发数量` int(11) NOT NULL DEFAULT '0' COMMENT '待发数量',
  `已发数量` int(11) NOT NULL DEFAULT '0' COMMENT '发送成功数量',
  `失败数量` int(11) NOT NULL DEFAULT '0' COMMENT '发送失败数量',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_短信详细`;
/* MySQLReback Separation */
 CREATE TABLE `dms_短信详细` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `d_id` int(11) NOT NULL DEFAULT '0',
  `接收号码` varchar(255) NOT NULL DEFAULT '',
  `接收人` varchar(255) NOT NULL DEFAULT '',
  `内容` varchar(255) NOT NULL DEFAULT '',
  `发送时间` int(11) NOT NULL DEFAULT '0',
  `状态` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 待发 1 已发 2 失败',
  `失败原因` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_短语`;
/* MySQLReback Separation */
 CREATE TABLE `dms_短语` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `短语内容` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_福利奖`;
/* MySQLReback Separation */
 CREATE TABLE `dms_福利奖` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `编号` varchar(50) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '',
  `获得时间` varchar(50) NOT NULL DEFAULT '',
  `发放时间` varchar(50) NOT NULL DEFAULT '',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_站外邮件`;
/* MySQLReback Separation */
 CREATE TABLE `dms_站外邮件` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `发件人` varchar(255) NOT NULL DEFAULT '管理员',
  `标题` varchar(255) NOT NULL DEFAULT '',
  `内容` text NOT NULL,
  `发送时间` int(11) NOT NULL DEFAULT '0',
  `收件人` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_管理_业绩`;
/* MySQLReback Separation */
 CREATE TABLE `dms_管理_业绩` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  `userid` int(8) NOT NULL DEFAULT '0',
  `fromid` int(8) NOT NULL DEFAULT '0',
  `val` decimal(14,2) NOT NULL DEFAULT '0.00',
  `region` int(2) NOT NULL DEFAULT '0',
  `saleid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `region` (`region`,`time`,`pid`),
  KEY `region_2` (`region`,`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_管理_业绩` DROP index `region`, DROP index `region_2`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_考核`;
/* MySQLReback Separation */
 CREATE TABLE `dms_考核` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `编号` varchar(50) NOT NULL DEFAULT '',
  `时间` int(11) NOT NULL DEFAULT '0',
  `连续` int(11) NOT NULL DEFAULT '0',
  `日期` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_货币`;
/* MySQLReback Separation */
 CREATE TABLE `dms_货币` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL DEFAULT '0',
  `编号` varchar(50) NOT NULL DEFAULT '',
  `电子货币` decimal(14,2) NOT NULL DEFAULT '0.00',
  `电子货币锁定` tinyint(1) NOT NULL DEFAULT '0',
  `电子货币提现累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `消费货币` decimal(14,2) NOT NULL DEFAULT '0.00',
  `消费货币锁定` tinyint(1) NOT NULL DEFAULT '0',
  `消费货币提现累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `游戏钱包` decimal(14,2) NOT NULL DEFAULT '0.00',
  `游戏钱包锁定` tinyint(1) NOT NULL DEFAULT '0',
  `游戏钱包提现累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userid` (`userid`),
  KEY `编号` (`编号`),
  CONSTRAINT `fk_userid` FOREIGN KEY (`userid`) REFERENCES `dms_会员` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_货币` DROP index `userid`, DROP index `编号`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_转账明细`;
/* MySQLReback Separation */
 CREATE TABLE `dms_转账明细` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `转出编号` varchar(50) NOT NULL DEFAULT '',
  `转出货币` varchar(50) NOT NULL DEFAULT '',
  `转出金额` decimal(12,2) NOT NULL DEFAULT '0.00',
  `手续费` decimal(12,2) NOT NULL DEFAULT '0.00',
  `转入编号` varchar(50) NOT NULL DEFAULT '',
  `转入货币` varchar(50) NOT NULL DEFAULT '',
  `转入金额` decimal(12,2) NOT NULL DEFAULT '0.00',
  `转换比率` decimal(12,2) NOT NULL DEFAULT '0.00',
  `操作时间` int(11) NOT NULL DEFAULT '0',
  `审核时间` int(11) NOT NULL DEFAULT '0',
  `状态` varchar(10) NOT NULL DEFAULT '',
  `备注` varchar(1000) NOT NULL DEFAULT '',
  `撤销理由` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_转账设置`;
/* MySQLReback Separation */
 CREATE TABLE `dms_转账设置` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '',
  `bank` varchar(50) NOT NULL DEFAULT '',
  `tobank` varchar(50) NOT NULL DEFAULT '',
  `tome` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 否 1 是',
  `toyou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 否 1 是',
  `toyoutype` varchar(250) NOT NULL DEFAULT '',
  `taxfrom` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 否 1 是',
  `tax` decimal(14,2) NOT NULL DEFAULT '0.00',
  `taxtop` decimal(14,2) NOT NULL DEFAULT '0.00',
  `taxlow` decimal(14,2) NOT NULL DEFAULT '0.00',
  `sacl` int(11) NOT NULL DEFAULT '0',
  `maxnum` decimal(14,2) NOT NULL DEFAULT '0.00',
  `minnum` decimal(14,2) NOT NULL DEFAULT '0.00',
  `intnum` int(11) NOT NULL DEFAULT '0',
  `nets` varchar(50) NOT NULL DEFAULT '',
  `shop` varchar(50) NOT NULL DEFAULT '',
  `time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 关闭 1 开启',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_邮件`;
/* MySQLReback Separation */
 CREATE TABLE `dms_邮件` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `发件人` varchar(255) NOT NULL DEFAULT '',
  `发件人类型` varchar(255) NOT NULL DEFAULT '管理员',
  `标题` varchar(255) NOT NULL DEFAULT '',
  `内容` text NOT NULL,
  `发送时间` int(11) NOT NULL DEFAULT '0',
  `收件人` varchar(255) NOT NULL DEFAULT '',
  `收件人类型` varchar(255) NOT NULL DEFAULT '',
  `状态` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 未查看 1 已查看 2 已回复 3 已删除',
  `回复人` text NOT NULL,
  `回复内容` text NOT NULL,
  `回复时间` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_银行卡`;
/* MySQLReback Separation */
 CREATE TABLE `dms_银行卡` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `开户行` varchar(100) NOT NULL DEFAULT '',
  `图标` varchar(100) NOT NULL DEFAULT '',
  `卡号` varchar(200) NOT NULL DEFAULT '',
  `户名` varchar(50) NOT NULL DEFAULT '',
  `状态` varchar(50) NOT NULL DEFAULT '有效',
  `测试` varchar(50) NOT NULL DEFAULT '有效',
  `开户银行官网` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_银行账户`;
/* MySQLReback Separation */
 CREATE TABLE `dms_银行账户` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(255) NOT NULL DEFAULT '',
  `标签` varchar(50) NOT NULL DEFAULT '',
  `银行` varchar(50) NOT NULL DEFAULT '',
  `银行卡号` varchar(50) NOT NULL DEFAULT '',
  `开户名` varchar(50) NOT NULL DEFAULT '',
  `省份` varchar(50) NOT NULL DEFAULT '',
  `城市` varchar(50) NOT NULL DEFAULT '',
  `区县` varchar(50) NOT NULL DEFAULT '',
  `时间` varchar(50) NOT NULL DEFAULT '',
  `状态` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `银行` (`银行`),
  KEY `标签` (`标签`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_银行账户` DROP index `userid`, DROP index `银行`, DROP index `标签`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_销售奖金`;
/* MySQLReback Separation */
 CREATE TABLE `dms_销售奖金` (
  `管理_左区本日业绩` decimal(14,2) NOT NULL DEFAULT '0.00',
  `管理_左区累计业绩` decimal(14,2) NOT NULL DEFAULT '0.00',
  `管理_左区结转业绩` decimal(14,2) NOT NULL DEFAULT '0.00',
  `管理_右区本日业绩` decimal(14,2) NOT NULL DEFAULT '0.00',
  `管理_右区累计业绩` decimal(14,2) NOT NULL DEFAULT '0.00',
  `管理_右区结转业绩` decimal(14,2) NOT NULL DEFAULT '0.00',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `计算日期` int(11) NOT NULL DEFAULT '0',
  `会员级别` tinyint(2) NOT NULL DEFAULT '1',
  `管理级别` tinyint(2) NOT NULL DEFAULT '1',
  `代理级别` tinyint(2) NOT NULL DEFAULT '1',
  `编号` varchar(50) NOT NULL DEFAULT '',
  `推荐_上级编号` varchar(50) NOT NULL DEFAULT '',
  `管理_上级编号` varchar(50) NOT NULL DEFAULT '',
  `奖金` decimal(14,2) NOT NULL DEFAULT '0.00',
  `收入` decimal(14,2) NOT NULL DEFAULT '0.00',
  `形成奖金` decimal(14,2) NOT NULL DEFAULT '0.00',
  `结转奖金` decimal(14,2) NOT NULL DEFAULT '0.00',
  `应发奖金` decimal(14,2) NOT NULL DEFAULT '0.00',
  `累计收入` decimal(14,2) NOT NULL DEFAULT '0.00',
  `显示` tinyint(2) NOT NULL DEFAULT '0',
  `生成日期` int(11) NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `推荐奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `推荐奖本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `推荐奖累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `碰对奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `碰对奖本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `碰对奖累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `层碰奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `层碰奖本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `层碰奖累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `责任消费` decimal(14,2) NOT NULL DEFAULT '0.00',
  `责任消费本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `责任消费累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `返利奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `返利奖本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `返利奖累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `级差奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `级差奖本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `级差奖累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `代理级差奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `代理级差奖本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `代理级差奖累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `分红奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `分红奖本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `分红奖累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `帮扶奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `帮扶奖本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `帮扶奖累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `店补` decimal(14,2) NOT NULL DEFAULT '0.00',
  `店补本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `店补累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  `所得税` decimal(14,2) NOT NULL DEFAULT '0.00',
  `所得税本月` decimal(14,2) NOT NULL DEFAULT '0.00',
  `所得税累计` decimal(14,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `编号` (`编号`),
  KEY `计算日期` (`计算日期`),
  KEY `state` (`state`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_销售奖金` DROP index `编号`, DROP index `计算日期`, DROP index `state`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_销售奖金总账`;
/* MySQLReback Separation */
 CREATE TABLE `dms_销售奖金总账` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `计算日期` int(11) NOT NULL DEFAULT '0',
  `总业绩` decimal(14,2) NOT NULL DEFAULT '0.00',
  `总奖金` decimal(14,2) NOT NULL DEFAULT '0.00',
  `本期业绩` decimal(14,2) NOT NULL DEFAULT '0.00',
  `本期奖金` decimal(14,2) NOT NULL DEFAULT '0.00',
  `推荐奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `碰对奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `层碰奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `责任消费` decimal(14,2) NOT NULL DEFAULT '0.00',
  `返利奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `级差奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `代理级差奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `分红奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `帮扶奖` decimal(14,2) NOT NULL DEFAULT '0.00',
  `店补` decimal(14,2) NOT NULL DEFAULT '0.00',
  `所得税` decimal(14,2) NOT NULL DEFAULT '0.00',
  `新增会员` int(11) NOT NULL DEFAULT '0',
  `全部会员` int(11) NOT NULL DEFAULT '0',
  `发放日期` varchar(50) NOT NULL DEFAULT '',
  `结算方式` tinyint(1) NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `计算日期` (`计算日期`),
  KEY `state` (`state`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_销售奖金总账` DROP index `计算日期`, DROP index `state`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_销售奖金构成`;
/* MySQLReback Separation */
 CREATE TABLE `dms_销售奖金构成` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dataid` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `prizename` varchar(100) NOT NULL DEFAULT '',
  `userid` int(11) NOT NULL DEFAULT '0',
  `fromid` int(11) NOT NULL DEFAULT '0',
  `val` decimal(14,2) NOT NULL DEFAULT '0.00',
  `trueval` decimal(14,2) NOT NULL DEFAULT '0.00',
  `memo` varchar(5000) NOT NULL DEFAULT '',
  `layer` int(11) NOT NULL DEFAULT '0',
  `tighten` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `dataid` (`dataid`),
  KEY `userid` (`userid`),
  KEY `prizename` (`prizename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `dms_销售奖金构成` DROP index `dataid`, DROP index `userid`, DROP index `prizename`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_首页图片`;
/* MySQLReback Separation */
 CREATE TABLE `dms_首页图片` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '',
  `位置` tinyint(1) NOT NULL DEFAULT '1',
  `imgpath` varchar(50) NOT NULL DEFAULT '',
  `顺序号` int(11) NOT NULL DEFAULT '0',
  `urlpath` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_apiget`;
/* MySQLReback Separation */
 CREATE TABLE `dms_apiget` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL DEFAULT '',
  `post` longtext NOT NULL,
  `model` varchar(255) NOT NULL DEFAULT '',
  `action` varchar(255) NOT NULL DEFAULT '',
  `addtime` int(11) NOT NULL DEFAULT '0',
  `acttime` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `result` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_apipost`;
/* MySQLReback Separation */
 CREATE TABLE `dms_apipost` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL DEFAULT '',
  `post` longtext NOT NULL,
  `model` varchar(255) NOT NULL DEFAULT '',
  `action` varchar(255) NOT NULL DEFAULT '',
  `addtime` int(11) NOT NULL DEFAULT '0',
  `acttime` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `trynum` int(11) NOT NULL DEFAULT '0',
  `result` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_fund`;
/* MySQLReback Separation */
 CREATE TABLE `dms_fund` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `money` decimal(13,2) NOT NULL DEFAULT '0.00',
  `left` decimal(13,2) NOT NULL DEFAULT '0.00',
  `use` decimal(13,2) NOT NULL DEFAULT '0.00' COMMENT '基金播出',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_fundlist`;
/* MySQLReback Separation */
 CREATE TABLE `dms_fundlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(255) NOT NULL DEFAULT '',
  `money` decimal(13,2) NOT NULL DEFAULT '0.00',
  `starttime` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_lang`;
/* MySQLReback Separation */
 CREATE TABLE `dms_lang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `dispname` varchar(50) NOT NULL DEFAULT '',
  `code` varchar(50) NOT NULL DEFAULT '',
  `othercode` varchar(50) NOT NULL DEFAULT '',
  `默认` int(11) NOT NULL DEFAULT '0',
  `生效` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_lang_data`;
/* MySQLReback Separation */
 CREATE TABLE `dms_lang_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `mode` text NOT NULL,
  `sq_code` text NOT NULL,
  `ar_code` text NOT NULL,
  `bg_code` text NOT NULL,
  `ca_code` text NOT NULL,
  `hr_code` text NOT NULL,
  `cs_code` text NOT NULL,
  `da_code` text NOT NULL,
  `nl_code` text NOT NULL,
  `et_code` text NOT NULL,
  `fa_code` text NOT NULL,
  `fi_code` text NOT NULL,
  `fr_code` text NOT NULL,
  `de_code` text NOT NULL,
  `el_code` text NOT NULL,
  `he_code` text NOT NULL,
  `hu_code` text NOT NULL,
  `is_code` text NOT NULL,
  `in_code` text NOT NULL,
  `it_code` text NOT NULL,
  `lv_code` text NOT NULL,
  `lt_code` text NOT NULL,
  `mk_code` text NOT NULL,
  `ms_code` text NOT NULL,
  `it_ch_code` text NOT NULL,
  `no_code` text NOT NULL,
  `pl_code` text NOT NULL,
  `pt_code` text NOT NULL,
  `rm_code` text NOT NULL,
  `ro_code` text NOT NULL,
  `ru_code` text NOT NULL,
  `sr_code` text NOT NULL,
  `sk_code` text NOT NULL,
  `sl_code` text NOT NULL,
  `es_code` text NOT NULL,
  `sv_code` text NOT NULL,
  `tr_code` text NOT NULL,
  `uk_code` text NOT NULL,
  `ja_code` text NOT NULL,
  `ko_code` text NOT NULL,
  `th_code` text NOT NULL,
  `vi_code` text NOT NULL,
  `en_us_code` text NOT NULL,
  `zh_tw_code` text NOT NULL,
  `zh_hk_code` text NOT NULL,
  `zh_cn_code` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_log`;
/* MySQLReback Separation */
 CREATE TABLE `dms_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL DEFAULT '0',
  `user_id` varchar(255) NOT NULL DEFAULT '',
  `user_type` varchar(255) NOT NULL DEFAULT '',
  `target_user_id` varchar(255) NOT NULL DEFAULT '',
  `target_user_type` varchar(255) NOT NULL DEFAULT '',
  `application` varchar(255) NOT NULL DEFAULT '',
  `module` varchar(255) NOT NULL DEFAULT '',
  `action` varchar(255) NOT NULL DEFAULT '',
  `old_data` text NOT NULL,
  `new_data` text NOT NULL,
  `post_data` text NOT NULL,
  `get_data` text NOT NULL,
  `ip` varchar(255) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `memo` varchar(255) NOT NULL DEFAULT '',
  `create_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_log_user`;
/* MySQLReback Separation */
 CREATE TABLE `dms_log_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL DEFAULT '0',
  `user_id` varchar(255) NOT NULL DEFAULT '',
  `content` varchar(255) NOT NULL DEFAULT '',
  `ip` varchar(255) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `create_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_loginrs`;
/* MySQLReback Separation */
 CREATE TABLE `dms_loginrs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) NOT NULL DEFAULT '',
  `starttime` int(11) NOT NULL DEFAULT '0',
  `endtime` int(11) NOT NULL DEFAULT '0',
  `errornum` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_lvlog`;
/* MySQLReback Separation */
 CREATE TABLE `dms_lvlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL DEFAULT '0',
  `username` varchar(50) NOT NULL DEFAULT '',
  `lvname` varchar(50) NOT NULL DEFAULT '',
  `time` int(11) NOT NULL DEFAULT '0',
  `olv` int(11) NOT NULL DEFAULT '0',
  `nlv` int(11) NOT NULL DEFAULT '0',
  `saleid` int(11) NOT NULL DEFAULT '0',
  `adminid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_onlinepay`;
/* MySQLReback Separation */
 CREATE TABLE `dms_onlinepay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `订单号` varchar(255) NOT NULL DEFAULT '',
  `编号` varchar(255) NOT NULL DEFAULT '',
  `金额` decimal(13,2) NOT NULL DEFAULT '0.00',
  `支付方式` varchar(255) NOT NULL DEFAULT '',
  `支付时间` varchar(15) NOT NULL DEFAULT '',
  `备注` varchar(255) NOT NULL DEFAULT '',
  `状态` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `dms_session`;
/* MySQLReback Separation */
 CREATE TABLE `dms_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(255) NOT NULL DEFAULT '' COMMENT 'session在浏览器中的表示SESSIONID',
  `session_data` varchar(5000) NOT NULL DEFAULT '',
  `session_expire` int(11) NOT NULL DEFAULT '0' COMMENT 'session最后修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `log`;
/* MySQLReback Separation */
 CREATE TABLE `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL DEFAULT '0',
  `user_id` varchar(255) NOT NULL DEFAULT '',
  `user_type` varchar(255) NOT NULL DEFAULT '',
  `target_user_id` varchar(255) NOT NULL DEFAULT '',
  `target_user_type` varchar(255) NOT NULL DEFAULT '',
  `application` varchar(50) NOT NULL DEFAULT '',
  `group` varchar(20) NOT NULL DEFAULT '',
  `module` varchar(50) NOT NULL DEFAULT '',
  `action` varchar(50) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `old_data` text NOT NULL,
  `new_data` text NOT NULL,
  `post_data` text NOT NULL,
  `get_data` text NOT NULL,
  `ip` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(50) NOT NULL DEFAULT '',
  `memo` varchar(50) NOT NULL DEFAULT '',
  `create_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `application` (`application`,`module`,`action`)
) ENGINE=MyISAM AUTO_INCREMENT=229 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `log` DROP index `application`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `mail_account`;
/* MySQLReback Separation */
 CREATE TABLE `mail_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `account` varchar(100) NOT NULL COMMENT '账号',
  `password` varchar(100) NOT NULL COMMENT '密码',
  `smtp` varchar(100) NOT NULL COMMENT '接收服务器',
  `port` varchar(10) NOT NULL COMMENT '接收端口',
  `ssl` enum('0','1') DEFAULT '0' COMMENT '加密套接字协议层',
  `times` int(11) DEFAULT NULL COMMENT '发送次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `node`;
/* MySQLReback Separation */
 CREATE TABLE `node` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `group` varchar(20) NOT NULL DEFAULT '' COMMENT '分组',
  `title` varchar(255) NOT NULL DEFAULT '',
  `args` varchar(255) NOT NULL DEFAULT '',
  `remark` varchar(255) NOT NULL DEFAULT '',
  `sort` smallint(6) unsigned NOT NULL DEFAULT '0',
  `pid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `is_sync_node` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否同步节点数据',
  `is_sync_menu` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否同步菜单数据',
  `is_quick_search` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否开启快捷搜索',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1会员节点,0管理员节点',
  `parent` varchar(255) NOT NULL DEFAULT '' COMMENT '菜单上级',
  `setParent` varchar(255) NOT NULL DEFAULT '' COMMENT '权限设置的显示上级',
  PRIMARY KEY (`id`),
  KEY `level` (`level`),
  KEY `pid` (`pid`),
  KEY `name` (`name`),
  KEY `name_pid_level` (`name`,`pid`,`level`)
) ENGINE=MyISAM AUTO_INCREMENT=180 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `node` DROP index `level`, DROP index `pid`, DROP index `name`, DROP index `name_pid_level`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `pay_event`;
/* MySQLReback Separation */
 CREATE TABLE `pay_event` (
  `orderid` varchar(255) NOT NULL DEFAULT '',
  `event` char(10) NOT NULL DEFAULT '' COMMENT '事件',
  `app` varchar(255) NOT NULL DEFAULT '' COMMENT '应用',
  `group` varchar(255) NOT NULL DEFAULT '' COMMENT '分组',
  `model` varchar(255) NOT NULL DEFAULT '' COMMENT '模型',
  `method` varchar(255) NOT NULL DEFAULT '' COMMENT '方法',
  `args` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `orderid` (`orderid`,`event`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `pay_event` DROP index `orderid`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `pay_onlineaccount`;
/* MySQLReback Separation */
 CREATE TABLE `pay_onlineaccount` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pay_type` varchar(255) NOT NULL DEFAULT '',
  `pay_attr` varchar(500) NOT NULL DEFAULT '',
  `pay_name` varchar(255) NOT NULL DEFAULT '',
  `pay_amount` double(10,2) NOT NULL DEFAULT '0.00',
  `name` varchar(255) NOT NULL DEFAULT '',
  `account` varchar(255) NOT NULL DEFAULT '',
  `state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `credit` varchar(12) NOT NULL DEFAULT '',
  `time` varchar(11) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `pay_order`;
/* MySQLReback Separation */
 CREATE TABLE `pay_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orderId` varchar(255) NOT NULL DEFAULT '',
  `money` double(10,2) NOT NULL DEFAULT '0.00',
  `realmoney` double(10,2) NOT NULL DEFAULT '0.00',
  `payment` varchar(255) NOT NULL DEFAULT '' COMMENT '支付方式',
  `payment_class` varchar(255) NOT NULL DEFAULT '',
  `create_time` int(10) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `memo` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `userid` varchar(50) DEFAULT '' COMMENT '编号',
  `username` varchar(50) DEFAULT '' COMMENT '姓名',
  `type` varchar(20) DEFAULT '' COMMENT '账户类型',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `role`;
/* MySQLReback Separation */
 CREATE TABLE `role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL DEFAULT '',
  `pid` smallint(6) NOT NULL DEFAULT '0',
  `remark` varchar(255) NOT NULL DEFAULT '',
  `ename` varchar(5) NOT NULL DEFAULT '',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 会员权限组,0管理员权限组',
  PRIMARY KEY (`id`),
  KEY `parentId` (`pid`),
  KEY `ename` (`ename`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `role` DROP index `parentId`, DROP index `ename`, DROP index `status`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `role_access`;
/* MySQLReback Separation */
 CREATE TABLE `role_access` (
  `role_id` smallint(6) unsigned NOT NULL DEFAULT '0',
  `node_id` smallint(6) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) NOT NULL DEFAULT '0',
  `pid` smallint(6) NOT NULL DEFAULT '0',
  KEY `nodeId` (`node_id`),
  KEY `roleId` (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `role_access` DROP index `nodeId`, DROP index `roleId`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `role_admin`;
/* MySQLReback Separation */
 CREATE TABLE `role_admin` (
  `role_id` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `admin_id` char(32) NOT NULL DEFAULT '',
  KEY `group_id` (`role_id`),
  KEY `user_id` (`admin_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `role_admin` DROP index `group_id`, DROP index `user_id`;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `xtable_set`;
/* MySQLReback Separation */
 CREATE TABLE `xtable_set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `标题` varchar(1000) NOT NULL DEFAULT '',
  `显示` varchar(255) NOT NULL DEFAULT '',
  `地址` varchar(255) NOT NULL DEFAULT '',
  `排序` varchar(255) NOT NULL DEFAULT '',
  `数组MD5` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 DROP TABLE IF EXISTS `yubicloud`;
/* MySQLReback Separation */
 CREATE TABLE `yubicloud` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int(10) NOT NULL DEFAULT '0',
  `yubi_prefix` varchar(12) NOT NULL DEFAULT '',
  `yubi_prefix_name` varchar(250) NOT NULL DEFAULT '',
  `addtime` int(11) DEFAULT '0' COMMENT '添加时间',
  `endtime` int(11) DEFAULT '0' COMMENT '失效时间',
  `state` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/* MySQLReback Separation */
 alter table `yubicloud` DROP index `account_id`;
/* MySQLReback Separation */