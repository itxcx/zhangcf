#!/bin/bash
start(){
        /root/server/huifu/huifu_server /root/server/huifu/server.conf > /root/server/huifu/server.log
        ps_check="`ps aux | grep huifu_server | wc -l`"
        if [ "$ps_check" = "1" ] ; then
                echo "huifu server start faild."

        elif [ "$ps_check" = "2" ] ; then
                echo "huifu server start success."
        fi
}

stop(){
        killall huifu_server && echo "huifu server stop success."
}

restart(){
        stop
        start
}

case "$1" in
restart)
        restart
        ;;
start)
        start
        ;;
stop)
        stop
        ;;
*)
      echo "Usage: $0 {restart | start | stop}"
      exit 1
esac
exit 1