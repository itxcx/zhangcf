/* This file is created by MySQLReback 2016-01-27 17:12:55 */
 alter table `admin` add UNIQUE index `account`(`account`) USING BTREE;
/* MySQLReback Separation */
 alter table `admin_access` add  index `adminId`(`admin_id`) USING BTREE, add  index `nodeId`(`node_id`) USING BTREE;
/* MySQLReback Separation */
 alter table `area` add UNIQUE index `地区编码`(`地区编码`) USING BTREE, add  index `id`(`id`) USING BTREE, add  index `上级编码`(`上级编码`) USING BTREE;
/* MySQLReback Separation */
 alter table `config` add UNIQUE index `name`(`name`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_产品` add  index `分类`(`分类`) USING BTREE, add  index `状态`(`状态`) USING BTREE, add  index `可订购数量`(`可订购数量`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_产品套餐` add  index `分类`(`分类`) USING BTREE, add  index `状态`(`状态`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_产品库存` add  index `报单id`(`报单id`) USING BTREE, add  index `产品id`(`产品id`) USING BTREE, add  index `产品节点`(`产品节点`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_产品订单` add  index `报单id`(`报单id`) USING BTREE, add  index `产品id`(`产品id`) USING BTREE, add  index `产品节点`(`产品节点`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_产品_分类` add  index `状态`(`状态`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_会员` add UNIQUE index `编号`(`编号`) USING BTREE, add  index `id`(`id`) USING BTREE, add  index `空点`(`空点`) USING BTREE, add  index `审核日期`(`审核日期`) USING BTREE, add  index `状态`(`状态`) USING BTREE, add  index `申请会员级别`(`申请会员级别`) USING BTREE, add  index `会员级别`(`会员级别`) USING BTREE, add  index `申请管理级别`(`申请管理级别`) USING BTREE, add  index `管理级别`(`管理级别`) USING BTREE, add  index `申请代理级别`(`申请代理级别`) USING BTREE, add  index `代理级别`(`代理级别`) USING BTREE, add  index `推荐_层数`(`推荐_层数`) USING BTREE, add  index `推荐_上级编号`(`推荐_上级编号`) USING BTREE, add  index `推荐_网体数据`(`推荐_网体数据`(200)) USING BTREE, add  index `管理_层数`(`管理_层数`) USING BTREE, add  index `管理_上级编号`(`管理_上级编号`) USING BTREE, add  index `管理_网体数据`(`管理_网体数据`(200)) USING BTREE, add  index `两层人数`(`两层人数`) USING BTREE, add  index `上月业绩`(`上月业绩`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_商城产品` add  index `分类`(`分类`) USING BTREE, add  index `状态`(`状态`) USING BTREE, add  index `可订购数量`(`可订购数量`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_商城产品套餐` add  index `分类`(`分类`) USING BTREE, add  index `状态`(`状态`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_商城产品_分类` add  index `状态`(`状态`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_报单` add  index `userid`(`userid`) USING BTREE, add  index `编号`(`编号`) USING BTREE, add  index `到款日期`(`到款日期`) USING BTREE, add  index `报单状态`(`报单状态`) USING BTREE, add  index `报单类别`(`报单类别`) USING BTREE, add  index `byname`(`byname`) USING BTREE, add  index `报单金额`(`报单金额`) USING BTREE, add  index `回填`(`回填`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_报单回填明细` add  index `saleid`(`saleid`) USING BTREE, add  index `编号`(`编号`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_汇款通知` add  index `编号`(`编号`) USING BTREE, add  index `状态`(`状态`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_消费货币明细` add  index `编号`(`编号`) USING BTREE, add  index `类型`(`类型`) USING BTREE, add  index `tlename`(`tlename`,`prizename`,`dataid`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_游戏钱包明细` add  index `编号`(`编号`) USING BTREE, add  index `类型`(`类型`) USING BTREE, add  index `tlename`(`tlename`,`prizename`,`dataid`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_申请回填` add  index `saleid`(`saleid`) USING BTREE, add  index `编号`(`编号`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_电子货币明细` add  index `编号`(`编号`) USING BTREE, add  index `类型`(`类型`) USING BTREE, add  index `tlename`(`tlename`,`prizename`,`dataid`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_管理_业绩` add  index `region`(`region`,`time`,`pid`) USING BTREE, add  index `region_2`(`region`,`pid`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_货币` add UNIQUE index `userid`(`userid`) USING BTREE, add  index `编号`(`编号`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_银行账户` add  index `userid`(`userid`) USING BTREE, add  index `银行`(`银行`) USING BTREE, add  index `标签`(`标签`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_销售奖金` add  index `编号`(`编号`) USING BTREE, add  index `计算日期`(`计算日期`) USING BTREE, add  index `state`(`state`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_销售奖金总账` add  index `计算日期`(`计算日期`) USING BTREE, add  index `state`(`state`) USING BTREE;
/* MySQLReback Separation */
 alter table `dms_销售奖金构成` add  index `dataid`(`dataid`) USING BTREE, add  index `userid`(`userid`) USING BTREE, add  index `prizename`(`prizename`) USING BTREE;
/* MySQLReback Separation */
 alter table `log` add  index `application`(`application`,`module`,`action`) USING BTREE;
/* MySQLReback Separation */
 alter table `node` add  index `level`(`level`) USING BTREE, add  index `pid`(`pid`) USING BTREE, add  index `name`(`name`) USING BTREE, add  index `name_pid_level`(`name`,`pid`,`level`) USING BTREE;
/* MySQLReback Separation */
 alter table `pay_event` add UNIQUE index `orderid`(`orderid`,`event`) USING BTREE;
/* MySQLReback Separation */
 alter table `role` add  index `parentId`(`pid`) USING BTREE, add  index `ename`(`ename`) USING BTREE, add  index `status`(`status`) USING BTREE;
/* MySQLReback Separation */
 alter table `role_access` add  index `nodeId`(`node_id`) USING BTREE, add  index `roleId`(`role_id`) USING BTREE;
/* MySQLReback Separation */
 alter table `role_admin` add  index `group_id`(`role_id`) USING BTREE, add  index `user_id`(`admin_id`) USING BTREE;
/* MySQLReback Separation */
 alter table `yubicloud` add  index `account_id`(`account_id`) USING BTREE;
/* MySQLReback Separation */